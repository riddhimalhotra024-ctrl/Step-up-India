const mysql = require('mysql2/promise');

// Create connection pool
const db = mysql.createPool({
  host: 'localhost',     // or your MySQL server
  user: 'root',          // your MySQL username
  password: 'yourpassword', // your MySQL password
  database: 'stepupindia'   // your database name
});

module.exports = db;