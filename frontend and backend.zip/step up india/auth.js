const express = require('express');
const bcrypt = require('bcrypt');
const mysql = require('mysql2');

const router = express.Router();

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '12345',          // your MySQL password
  database: 'stepup_india'    // your schema
});

// REGISTER route
router.post('/register', async (req, res) => {
  const { name, email, password, role } = req.body;

  try {
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = 'INSERT INTO users (student_name, email, password, role) VALUES (?, ?, ?, ?)';
    db.query(sql, [name, email, hashedPassword, role], (err, result) => {
      if (err) {
        console.error('Error inserting user:', err);
        return res.status(500).json({ message: 'Error registering user' });
      }
      res.json({ message: 'User registered successfully!' });
    });
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// LOGIN route
// LOGIN route
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  const sql = 'SELECT * FROM users WHERE email = ?';
  db.query(sql, [email], async (err, results) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ message: 'Database error' });
    }
    if (results.length === 0) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const user = results[0];

    try {
      // ✅ Compare entered password with hashed password
      const match = await bcrypt.compare(password, user.password);
      if (!match) {
        return res.status(400).json({ message: 'Invalid credentials' });
      }

      // ✅ Send JSON with student_name
      res.json({ 
        message: `Welcome back, ${user.student_name}!`, 
        name: user.student_name 
      });
    } catch (error) {
      console.error('Error comparing password:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });
});
// ENROLL route
router.post('/enroll', (req, res) => {
  const { studentId, courseId } = req.body;
  const sql = 'INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)';
  db.query(sql, [studentId, courseId], (err, result) => {
    if (err) {
      console.error('Error enrolling:', err);
      return res.status(500).json({ message: 'Error enrolling' });
    }
    res.json({ message: 'Enrolled successfully!' });
  });
});

// Get all enrollments for a student
router.get('/enrollments/:studentId', (req, res) => {
  const { studentId } = req.params;
  const sql = `
    SELECT c.id, c.title, c.description 
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    WHERE e.student_id = ?`;
  db.query(sql, [studentId], (err, results) => {
    if (err) {
      console.error('Error fetching enrollments:', err);
      return res.status(500).json({ message: 'Error fetching enrollments' });
    }
    res.json(results);
  });
});

// ✅ This line is CRUCIAL
module.exports = router;