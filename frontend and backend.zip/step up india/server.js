const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const authRoutes = require('./auth'); // import your auth.js file

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Create MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12345',        // your MySQL password
    database: 'stepup_india'  // your schema name
});

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.error('❌ Database connection failed:', err.stack);
        return;
    }
    console.log('✅ Connected to MySQL database.');
});

// Mount the auth routes
app.use('/auth', authRoutes);
console.log("✅ Auth routes mounted");

// Test route
app.get('/', (req, res) => {
    res.send('Step-Up India Backend is running!');
});

// 👉 New route to fetch students
app.get('/users', (req, res) => {
    const query = 'SELECT id, student_name, email, role, created_at FROM users';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching students:', err);
            return res.status(500).json({ error: 'Database query failed' });
        }
        res.json(results);
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
